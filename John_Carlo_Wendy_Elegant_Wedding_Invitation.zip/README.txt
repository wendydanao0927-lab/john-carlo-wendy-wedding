DIGITAL WEDDING INVITATION — JOHN CARLO & WENDY

Details:
October 6, 2026 (Tuesday), 2:30 PM
Reception: The Forest Haven Private Resort
Dress code: Powder Blue Formal Attire
Google Maps: https://maps.app.goo.gl/Gd7akGPuenTzgwJJ6

No RSVP button or form is included.

MUSIC:
The website has a music player prepared for "Palagi" by TJ Monterde, but the copyrighted audio recording is not included. If you have a copy you are legally permitted to use, create a folder named "music" and put it there as music/palagi.mp3.

PREVIEW:
Double-click index.html.

PUBLISH:
Upload the complete folder to a static host such as Netlify or GitHub Pages. Keep the folder structure intact.